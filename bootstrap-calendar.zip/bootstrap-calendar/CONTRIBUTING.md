If you want to contribute please follow this instruction.

1. Fork repository.
2. Clone to your PC or Mac.
3. Navigate to repository directory 
4. Run
 
       npm instal -g grunt grunt-cli;
       npm install
5. Create new `fix` or `feature` branch
6. Make modifications

   Please do not make magnified version of `calendar.js`

8. Push to github and send Pull Request.
